
var_file = open("test.txt", "w")
var_file.write("OpenKunix Dev 2 File")
var_file.close()
print("Done file is created")