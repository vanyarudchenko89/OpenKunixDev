var_file = open(n, "file.txt")
var_file.write("Open Kunix 4.0 Developer Preview 1 GUI Notepad save test (custom text saving was added soon)")
var_file.close()