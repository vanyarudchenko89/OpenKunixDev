import tkinter as tk
from datetime import datetime
import webbrowser

def notepad():
    window1 = tk.Tk()
    window1.title("Notepad")
    window1.geometry("640x480")
    tk.Entry(window1, width=105).grid(column=0, row=1)
    tk.Button(window1, text="Save", command=print("Text saving was fully added soon")).grid(column=2, row=2)


def clock():

        window2 = tk.Tk()
        window2.title("")
        window2.geometry("150x100")
        t1 = datetime.now().time()
        tk.Label(window2,text=t1).grid(row=0, column=0)

        window2.mainloop()

def paint():
    import turtle
    turtle.title("OpenPaint")
    def mU():
        pos = turtle.pos()
        turtle.goto(pos[0], pos[1] + 5)

    def mD():
        pos = turtle.pos()
        turtle.goto(pos[0], pos[1] - 5)

    def mR():
        pos = turtle.pos()
        turtle.goto(pos[0] + 5, pos[1])

    def mL():
        pos = turtle.pos()
        turtle.goto(pos[0] - 5, pos[1])

    def pD():
        if turtle.isdown() == 1:
            turtle.penup()
        else:
            turtle.pendown()

    def cL():
        turtle.clear()

    turtle.onkey(mU, "Up")
    turtle.onkey(mD, "Down")
    turtle.onkey(mL, "Left")
    turtle.onkey(mR, "Right")
    turtle.onkey(cL, "0")
    turtle.onkey(pD, "space")

    turtle.listen()
    turtle.mainloop()

def about():
    window4 = tk.Tk()
    window4.title("About OpenKunix")
    window4.geometry("510x300")
    tk.Label(window4, text="Open Kunix 4.0 Developer Preview 1").grid(row=0, column=0)
    tk.Label(window4, text="DephiSoft").grid(row=1, column=0)
    tk.Label(window4, text="Visit: https://vanyarudchenko89.github.io/OpenKunixDev/").grid(row=2, column=0)
    tk.Label(window4, text="first update in 2024!").grid(row=3, column=0)

def commandmode():
    import cmd

def settings():
    window5 = tk.Tk()
    window5.title("Settings")
    window5.geometry("400x300")
    tk.Label(window5, text="Settings").grid(row=0, column=0)
    tk.Button(window5, text="Background", command=background).grid(column=2, row=2)
    window5.mainloop()

def background():
    system["bg"] = "gray"


system = tk.Tk()
system.title("Open Kunix 4.0 Developer Preview")
system.geometry("800x600")

tk.Button(system,text="Notepad", command=notepad).grid(column=2, row=2)
tk.Button(system,text="Clock", command=clock).grid(column=2, row=3)
tk.Button(system,text="PaintBrush", command=paint).grid(column=2, row=5)
tk.Button(system,text="About", command=about).grid(column=2, row=6)
tk.Button(system,text="Command Mode", command=commandmode).grid(column=2, row=7)
tk.Button(system,text="Settings", command=settings).grid(column=2, row=8)





system.mainloop()