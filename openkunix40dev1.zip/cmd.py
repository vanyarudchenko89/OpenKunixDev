print("OpenKunix")
print("help to display commands")
while 1:
    command = input(">>")

    if command =="help":
       print("'Commands'")
       print("settings")
       print("turn-off")
       print("createfile")

    if command =="turn-off":
       print("turn-off your computer")

    
    if command == "createfile":
       import kunixsavetest




