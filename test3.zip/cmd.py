print("Open Kunix v3.0 Dev 3 (build 101023)")

i = 0

while i < 1:
    command = input(">> ")

    if command == "About":
        print("OpenKunix 3.0 Dev 3 (Build 101023)")

    if command == "createfile":
        import kunixsavetest

    if command == "Help":
        print("Commands:")
        print("About")
        print("createfile (dev function)")