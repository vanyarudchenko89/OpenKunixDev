class text():
    w = "Welcome"

class version():
    view = "OpenKunix 3.0 Developer release 3"

class app():
    version = "v1.0"
    info = "Open Kunix classes (Now not used)"




