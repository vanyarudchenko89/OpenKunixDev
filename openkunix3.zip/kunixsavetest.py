n = input("File name (with format):")
i = input("")

var_file = open(n, "w")
var_file.write(i)
var_file.close()
print("Done file is created")